<?php

require_once ('DB.php');
require_once ('model/Country.php');

DB::connect('localhost', 'world', 'root', '');

$name = $_GET["name"] ?? '';
$continent = $_GET["continent"] ?? '';
$population = $_GET["population"] ?? 0;

$query = "SELECT * FROM `countries`";
$queryParams = [];

$resultList = DB::select($query, $queryParams, Country::class);

var_dump($resultList);
