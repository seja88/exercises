module.exports = {

    'src/css/style.scss':  'dist/css/style.css',
    'src/js/script.js':    'dist/js/script.js',

}